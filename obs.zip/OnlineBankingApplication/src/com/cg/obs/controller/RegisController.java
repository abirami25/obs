package com.cg.obs.controller;

package com.cg.obs.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.obs.bean.OBSBean;
import com.cg.obs.dao.OBSDao;
import com.cg.obs.services.OBSServices;



	public class RegisController extends HttpServlet {
		 
		public  void doGet(HttpServletRequest request, HttpServletResponse response) 
				   throws ServletException,IOException 
				{
					RequestDispatcher rd = null;
					int Cust_id=0;
					String title="";
					
					String user_id=request.getParameter("cuserid");
					String login_password=request.getParameter("cpassword");
					String secret=request.getParameter("canswer");
					String trans_password=request.getParameter("tpassword");
					String lstatus="n";
					
					OBSServices obsservices=new OBSServices();
					
					OBSDao obsdao=new OBSDao();
					//OBSBean obsbean=new OBSBean();
					
					 int updateCount = obsservices.addregisobs(user_id, login_password,secret,trans_password,lstatus);
						
						System.out.println("inserted "+updateCount+" record   Success");
						
						if (updateCount==1) {
							rd = request.getRequestDispatcher("/success.jsp");
							
						} else {
							rd = request.getRequestDispatcher("/error.jsp");
						}
						rd.forward(request, response);
					}
					
					
				
	
}
