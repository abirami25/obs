package com.cg.obs.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.obs.dao.OBSDao;
import com.cg.obs.services.OBSServices;

public class AccountController extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException 
	{ 
		RequestDispatcher rd = null; 
		int Cust_id=0; 
		String title=""; 
		String cust_name = request.getParameter("custname"); 
		String email = request.getParameter("custemail"); 
		String pan = request.getParameter("custpan"); 
		
		String acctype = request.getParameter("acctype");
		String accbal = request.getParameter("accbal"); 
		
		OBSServices obsservices=new OBSServices(); 
		OBSDao obsdao=new OBSDao(); 
		 
		int updateCount = obsservices.addaccountobs(acctype, accbal, cust_name, email, pan);
		System.out.println("inserted "+updateCount+" record Success"); 
		
		if (updateCount==1) 
		
		{ 
			rd = request.getRequestDispatcher("/success.jsp"); 
			
		} 
		
		else 
		{ 
			rd = request.getRequestDispatcher("/error.jsp"); 
			} 
		
		rd.forward(request, response); } 

	
}