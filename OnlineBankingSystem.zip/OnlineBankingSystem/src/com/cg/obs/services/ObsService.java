package com.cg.obs.services;

import com.cg.obs.bean.AccountBean;
import com.cg.obs.bean.OBSBean;
import com.cg.obs.bean.PayeeBean;
import com.cg.obs.bean.RegisBean;
import com.cg.obs.dao.OBSDao;

public class OBSService {
public int addregisobs(String user_id, String login_pass, String secret, String tpass, String lpass) {
	
	
	OBSDao obsdao=new OBSDao();
	OBSBean obsbean=new OBSBean();
	RegisBean regisobsbean=new RegisBean();
	
	
	regisobsbean.setUser_id(user_id);
	regisobsbean.setLogin_password(login_pass);
	regisobsbean.setSecret(secret);
	regisobsbean.setTransaction_password(tpass);
	regisobsbean.setLock_status(lpass);
	 int updateResult = 0;
	 try
	 {
		 updateResult = obsdao.addrobs(regisobsbean);
		 return updateResult;
	 }
	 catch(Exception ex)
	 {
		 System.out.println(ex.toString());
		 return 0;
	 }
	
	
	
	
}

public int addaccountobs(String acctype, int accbal, String custname, String email, String pan) {
	OBSDao obsdao=new OBSDao();
	AccountBean accountobsbean=new AccountBean();
	
	accountobsbean.setAcc_type(acctype);
	accountobsbean.setAcc_bal(accbal);
	accountobsbean.setCust_name(custname);
	accountobsbean.setEmail(email);
	accountobsbean.setPancard(pan);
	
	int updateResult = 0;
	 try
	 {
		 updateResult = obsdao.addaccount(accountobsbean);
		 return updateResult;
	 }
	 catch(Exception ex)
	 {
		 System.out.println(ex.toString());
		 return 0;
	 }
	
}

public int addpayeeobs(String payee_id, String nickname) {
	
	OBSDao obsdao=new OBSDao();
	PayeeBean payeeobsbean=new PayeeBean();
	
	payeeobsbean.setPacc_id(payee_id);
	payeeobsbean.setNickname(nickname);
	
	int updateResult = 0;
	 try
	 {
		 updateResult = obsdao.addpayee(payeeobsbean);
		 return updateResult;
	 }
	 catch(Exception ex)
	 {
		 System.out.println(ex.toString());
		 return 0;
	 }
	
}

}

