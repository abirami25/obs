package com.cg.obs.services;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserLogin extends HttpServlet
{
  public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
  {
	  try
	  {
		  RequestDispatcher rd = null;
		 res.setContentType("text/html"); 
	     PrintWriter out = res.getWriter();
	     String name = req.getParameter("userName");
	     out.println("Welcome "+name);
	     if(true)
	     {
	     rd = req.getRequestDispatcher("/userHome.jsp");
	     }
	     rd.forward(req, res);
	     out.close();
	  }
	  catch(Exception excp)
	  {
		  System.out.println(excp);
	  }
  }
}