package com.cg.obs.dao;

package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.obs.bean.AccountBean;
import com.cg.obs.bean.OBSBean;
import com.cg.obs.bean.PayeeBean;
import com.cg.obs.bean.RegisBean;
import com.cg.obs.dao.OBSDatabase;

public class ObsDAO {

	public int addrobs(RegisBean bean)
	  {
		  Connection con = null;
		  PreparedStatement pstmt = null;
		  try
		  {
			  /* Class.forName("com.mysql.jdbc.Driver");
		         con = DriverManager.getConnection(
		         "jdbc:mysql://localhost:3309/accdb","root","root"); 
		     */
			  con=OBSDatabase.getConnection(); 
			  
			  String ins_str = "insert into UserTable values(account_id_seq.nextval,?,?,?,?,?)";
			  
			  pstmt = con.prepareStatement(ins_str);
			  
			  pstmt.setString(1,bean.getUser_id());
			  pstmt.setString(2,bean.getLogin_password());
			  pstmt.setString(3,bean.getSecret());
			  pstmt.setString(4,bean.getTransaction_password());
			  pstmt.setString(5,bean.getLock_status());
			  
			  
			  int updateCount = pstmt.executeUpdate();
			  
			  con.close();
			  
			  return updateCount;
			  
			  
		  }
		  catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
		  
	  }
	
public int addaccount(AccountBean bean1) {
		
        Connection con = null; 
		
		PreparedStatement pstmt = null; 
	
		
	
		try { 
			/* Class.forName("com.mysql.jdbc.Driver"); 
			 * con = DriverManager.getConnection( "jdbc:mysql://localhost:3309/accdb","root","root"); */ 
			
			
			con=OBSDatabase.getConnection(); 
			
			String ins_str = "insert into AccountMaster values(account_id_seq_master.nextval,?,?,sysdate,?,?,?,?)"; 
			pstmt = con.prepareStatement(ins_str); 
			pstmt.setString(1,bean1.getAcc_type()); 
			pstmt.setInt(2,bean1.getAcc_bal());
			pstmt.setString(3,bean1.getCust_name());
			pstmt.setString(4,bean1.getEmail());
			pstmt.setString(5,bean1.getPancard());
			
			
			 
			int updateCount = pstmt.executeUpdate(); 
			con.close(); 
			
			return updateCount;
			
		} 
		
		
		catch(Exception ex) 
		{ 
			System.out.println(ex.toString()); 
			
			return 0; 
			
		} 
		
	}

public int addpayee(PayeeBean bean3) {
	
	 Connection con = null; 
		
		PreparedStatement pstmt = null;
		
		try {
			con=OBSDatabase.getConnection(); 
			

			String ins_str = "insert into PayeeTable values(?,?)";
			
			pstmt = con.prepareStatement(ins_str); 
			pstmt.setString(1,bean3.getPacc_id());
			pstmt.setString(2,bean3.getNickname());
			
			
			int updateCount = pstmt.executeUpdate(); 
			con.close(); 
			
			return updateCount;
			
			
		}
		
		catch(Exception ex) {
			
			System.out.println(ex);
			
			return 0;
		}
	
}

	  
	  
	  // Below method, Search by ID Module.    
	/*  public ArrayList getBookDetailsById(int bookId)
				throws Exception
				{
					Connection con = null;
					PreparedStatement pstmt = null;
					ResultSet rs = null;
					
					con = OBSDatabase.getConnection();
					
			    String sel_str ="Select title,price from book where bookId=?";
					  
					  
					  pstmt = con.prepareStatement(sel_str);
					  pstmt.setInt(1,bookId);
					  rs = pstmt.executeQuery();
					  
					  ArrayList result = new ArrayList();
					  if(rs.next())
					  {
						  result.add(rs.getString(1));
						  result.add(rs.getString(2));
						  
					  }
					  else
					  {
						  result.add("Invalid Id");
					  }
					  return result;
					
				}*/
	
}
